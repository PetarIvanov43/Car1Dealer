﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Data
{
    public class Fuel
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(20)]
        public string FuelType { get; set; }
    }
}
