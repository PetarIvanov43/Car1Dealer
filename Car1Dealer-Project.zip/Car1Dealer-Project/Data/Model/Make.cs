﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace Data.Model
{
    public class Make
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(20)]
        public string MakeName { get; set; }

        public ICollection<CarModel> CarModels { get; set; } = new List<CarModel>();
        public ICollection<Car> Cars { get; set; } = new List<Car>();
    }
}
