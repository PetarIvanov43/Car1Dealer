﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Data.Model
{
    public class EuroStandard
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(20)]
        public string EuroStandardType { get; set; }
    }
}
