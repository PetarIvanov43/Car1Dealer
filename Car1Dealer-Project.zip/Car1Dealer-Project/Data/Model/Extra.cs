﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace Data.Model
{
    public class Extra
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(20)]
        public string ExtraType { get; set; }

        public ICollection<CarExtra> CarExtras { get; set; } = new HashSet<CarExtra>();
    }
}
