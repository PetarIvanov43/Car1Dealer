﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Data
{
    using Data.Model;
    public class Car1DealerContext : DbContext
    {
        public DbSet<Fuel> FuelTypes { get; set; }
        public DbSet<EuroStandard> EuroStandards { get; set; }
        public DbSet<Make> Makes { get; set; }
        public DbSet<CarModel> CarModels { get; set; }
        public DbSet<Gearbox> Gearboxes { get; set; }
        public DbSet<DoorsCount> DoorCounts { get; set; }
        public DbSet<VehicleType> VehicleTypes { get; set; }
        public DbSet<Extra> Extras { get; set; }
        public DbSet<Paint> Paints { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<CarExtra> CarsExtras { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(DataSettings.DefaultConnection);
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder
                .Entity<Car>()
                .HasOne(c => c.Make)
                .WithMany(m => m.Cars)
                .OnDelete(DeleteBehavior.NoAction);

            modelBuilder
                .Entity<CarModel>()
                .HasOne(cm => cm.Make)
                .WithMany(m => m.CarModels)
                .HasForeignKey(cm => cm.MakeId);

            modelBuilder
                .Entity<CarExtra>(entity => 
                { 
                    entity.HasKey(x => new { x.CarId, x.ExtraId }); 
                });
        }
    }
}
