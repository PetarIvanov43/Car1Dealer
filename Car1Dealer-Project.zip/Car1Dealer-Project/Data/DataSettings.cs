﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data
{
    public class DataSettings
    {
        public const string DefaultConnection = "Server=.;Database=Car1Dealer;Integrated Security=True";
    }
}
