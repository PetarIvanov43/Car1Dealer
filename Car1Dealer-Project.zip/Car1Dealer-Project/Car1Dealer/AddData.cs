﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Car1Dealer
{
    public partial class AddData : Form
    {
        public AddData()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Show AddMake form and hide this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMake_Click(object sender, EventArgs e)
        {
            AddMake addMake = new AddMake();
            addMake.Show();
            this.Hide();
        }

        /// <summary>
        /// Show AddModel form and hide this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnModel_Click(object sender, EventArgs e)
        {
            AddModel addModel = new AddModel();
            addModel.Show();
            this.Hide();
        }

        /// <summary>
        /// Show AddType form and hide this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnType_Click(object sender, EventArgs e)
        {
            AddType addType = new AddType();
            addType.Show();
            this.Hide();
        }

        /// <summary>
        /// Show AddExtra form and hide this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExtra_Click(object sender, EventArgs e)
        {
            AddExtras addExtra = new AddExtras();
            addExtra.Show();
            this.Hide();
        }

        /// <summary>
        /// Show AddPaint form and hide this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPaint_Click(object sender, EventArgs e)
        {
            AddPaint addPaint = new AddPaint();
            addPaint.Show();
            this.Hide();
        }
    }
}
