﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Business;
using Business.ViewModels;
using Business.DataOperations;
using Data;

namespace Car1Dealer
{
    public partial class Extras : Form
    {
        GetDataOperations GetDataOperations = new GetDataOperations();

        /// <summary>
        /// Adds every extra from the database as items in
        /// the checkedListBox's collection
        /// </summary>
        public Extras()
        {
            InitializeComponent();
            using var db = new Car1DealerContext();


            Form1.extras.Clear();


            foreach (var item in GetDataOperations.GetAllExtras(db))
            {
                if (!checkedListBox1.Items.Contains(item))
                {
                    checkedListBox1.Items.Add(item);
                }
            }

        }

        /// <summary>
        /// Clears the extras list from Form1 and add the items from
        /// the checked fields from the checkedListBox.Then hides this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnApply_Click(object sender, EventArgs e)
        {
            Form1.extras.Clear();
            foreach (var item in checkedListBox1.CheckedItems)
            {
                Form1.extras.Add(item.ToString());
            }

            this.Hide();
        }
    }
}
