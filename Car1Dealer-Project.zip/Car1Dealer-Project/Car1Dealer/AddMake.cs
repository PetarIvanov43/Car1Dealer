﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Data;
using Business.DataOperations;

namespace Car1Dealer
{
    public partial class AddMake : Form
    {
        AddDataOperations AddDataOperations = new AddDataOperations();
        public AddMake()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Adds a new make, shows the message that the method AddNewMakeToDB
        /// from AddDataOperations returns and hide this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            using var db = new Car1DealerContext();
            string message = AddDataOperations.AddNewMakeToDB(db, textBox1.Text);
            this.Hide();
            MessageBox.Show(message);
        }
    }
}
