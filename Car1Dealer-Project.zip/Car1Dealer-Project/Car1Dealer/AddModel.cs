﻿using Business.DataOperations;
using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Car1Dealer
{
    public partial class AddModel : Form
    {
        GetDataOperations GetDataOperations = new GetDataOperations();
        AddDataOperations AddDataOperations = new AddDataOperations();

        /// <summary>
        /// Adds all of the makes from the database as items to the comboBox's collection
        /// </summary>
        public AddModel()
        {
            InitializeComponent();

            using var db = new Car1DealerContext();
            foreach (var item in GetDataOperations.GetAllMakes(db))
            {
                comboBox1.Items.Add(item);
            }
        }

        /// <summary>
        /// Adds a new model to the database,hides this form and shows the message that the method AddNewModelToDB
        /// from the class AddDataOperations returns in MessageBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            using var db = new Car1DealerContext();
            string message = AddDataOperations.AddNewModelToDB(db, comboBox1.SelectedItem.ToString(), textBox1.Text);
            this.Hide();
            MessageBox.Show(message);
        }
    }
}
