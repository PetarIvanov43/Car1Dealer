﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Business;
using Business.ViewModels;
using Business.DataOperations;
using Data;

namespace Car1Dealer
{
    public partial class EditingExtras : Form
    {

        GetDataOperations GetDataOperations = new GetDataOperations();

        /// <summary>
        /// Clears the extras list from Form1, adds all of the extras
        /// from the database to the checkedListBox ands check all of
        /// them
        /// </summary>
        public EditingExtras()
        {
            InitializeComponent();
            using var db = new Car1DealerContext();

            Form1.extras.Clear();

            CarFullInfoModel adCar = GetDataOperations.GetFullInfo(db, Form1.carId);

            foreach (var item in GetDataOperations.GetAllExtras(db))
            {
                if (!checkedListBox1.Items.Contains(item))
                {
                    checkedListBox1.Items.Add(item);
                }
            }

            List<string> chkBoxList = new List<string>();

            foreach (var extra in checkedListBox1.Items)
            {
                chkBoxList.Add(extra.ToString());
            }

            foreach (var item in chkBoxList)
            {
                if (adCar.CarExtras.Contains(item))
                {
                    checkedListBox1.SetItemChecked(chkBoxList.IndexOf(item), true);
                }
            }

        }

        /// <summary>
        /// Clears the extras list from Form1,adds the checked items in
        /// the checkedListBox to the list extras and hides this form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnApply_Click(object sender, EventArgs e)
        {
            Form1.extras.Clear();
            foreach (var item in checkedListBox1.CheckedItems)
            {
                Form1.extras.Add(item.ToString());
            }

            this.Hide();
        }
    }
}
