﻿using Business.DataOperations;
using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Car1Dealer
{
    public partial class AddPaint : Form
    {
        AddDataOperations AddDataOperations = new AddDataOperations();
        public AddPaint()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Adds a new paint to the database,hides this form and shows in MessageBox the message that
        /// the method AddNewPaintToDB from the class AddDataOperations returns
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {

            using var db = new Car1DealerContext();
            string message = AddDataOperations.AddNewPaintToDB(db, textBox1.Text);
            this.Hide();
            MessageBox.Show(message);
        }
    }
}
