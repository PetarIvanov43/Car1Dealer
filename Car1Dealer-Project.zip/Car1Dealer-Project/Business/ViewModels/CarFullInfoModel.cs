﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Business.ViewModels
{
    public class CarFullInfoModel
    {
        public int Id { get; set; }
        public string Make { get; set; }
        public string CarModel { get; set; }
        public string Modification { get; set; }
        public string Fuel { get; set; }
        public string Type { get; set; }
        public int EngineCapacity { get; set; }
        public int EnginePower { get; set; }
        public string Gearbox { get; set; }
        public string EuroStandard { get; set; }
        public string Doors { get; set; }
        public int Kilometers { get; set; }
        public string Paint { get; set; }
        public List<string> CarExtras { get; set; } = new List<string>();
        public string Information { get; set; }
        public decimal Price { get; set; }

        public CarFullInfoModel(int id, string make, string carModel, 
            string modification, string fuel, string type, int engineCapacity,
            int enginePower, string gearbox, string euroStandard, string doors,
            int kilometers, string paint, string information,
            decimal price)
        {
            this.Id = id;
            this.Make = make;
            this.CarModel = carModel;
            this.Modification = modification;
            this.Fuel = fuel;
            this.Type = type;
            this.EngineCapacity = engineCapacity;
            this.EnginePower = enginePower;
            this.Gearbox = gearbox;
            this.EuroStandard = euroStandard;
            this.Doors = doors;
            this.Kilometers = kilometers;
            this.Paint = paint;
            this.Information = information;
            this.Price = price;
        }

        public CarFullInfoModel()
        {

        }
    }
}
