﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Business.ViewModels
{
     public class CarSearchDataModel
    {
               
        public string SelectedMake { get; set; }
        public string SelectedModel { get; set; }
        public string SelectedFuel { get; set; }
        public string SelectedType { get; set; }
        public int MinEnginePower { get; set; }
        public int MaxEnginePower { get; set; }
        public string SelectedGearbox { get; set; }
        public string SelectedDoors { get; set; }
        public decimal MinPrice { get; set; }
        public decimal MaxPrice { get; set; }
        public List<string> SlectadExtras { get; set; } = new List<string>();
    }
}
