﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Business.ViewModels
{
    public class CarPreviewModel
    {
        public int Id { get; set; }
        public string Make { get; set; }
        public string CarModel { get; set; }
        public string Modification { get; set; }
        public int Kilometers { get; set; }
        public string Fuel { get; set; }
        public decimal Price { get; set; }

        public CarPreviewModel(int id, string make, string carModel, string modification, int kilometers, string fuel, decimal price)
        {
            this.Id = id;
            this.Make = make;
            this.CarModel = carModel;
            this.Modification = modification;
            this.Kilometers = kilometers;
            this.Fuel = fuel;
            this.Price = price;
        }
    }
}
