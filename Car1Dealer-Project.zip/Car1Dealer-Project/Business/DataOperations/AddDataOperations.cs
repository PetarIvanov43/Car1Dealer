﻿using Business.ViewModels;
using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.DataOperations
{
    /*
     The class AddDataOperations adds data to the database
    using methods
    */
    public class AddDataOperations
    {

        /// <summary>
        /// This method adds a new car to the database
        /// </summary>
        /// <param name="context"></param>
        /// <param name="addCarInfoModel"></param>
        /// <returns>message from type string that shows whether
        /// the new car is succesfully added or no</returns>
        public string AddNewCarToDB(Car1DealerContext context, CarFullInfoModel addCarInfoModel)
        {
            int carsCount = context.Cars.Count();
            string message = "New car failed to add";

            Car carToAdd = new Car();

            int makeId = context.Makes
                    .FirstOrDefault(m => m.MakeName == addCarInfoModel.Make)
                    .Id;
            carToAdd.MakeId = makeId;

            int modelId = context.CarModels
                    .FirstOrDefault(m => m.ModelName == addCarInfoModel.CarModel)
                    .Id;
            carToAdd.CarModelId = modelId;

            int typeId = context.VehicleTypes
                    .FirstOrDefault(m => m.TypeName == addCarInfoModel.Type)
                    .Id;
            carToAdd.TypeId = typeId;

            int fuelId = context.FuelTypes
                    .FirstOrDefault(m => m.FuelType == addCarInfoModel.Fuel)
                    .Id;
            carToAdd.FuelId = fuelId;

            int gearboxId = context.Gearboxes
                    .FirstOrDefault(m => m.GearboxType == addCarInfoModel.Gearbox)
                    .Id;
            carToAdd.GearboxId = gearboxId;

            if (!String.IsNullOrEmpty(addCarInfoModel.EuroStandard))
            {
                int euroStandardId = context.EuroStandards
                        .FirstOrDefault(m => m.EuroStandardType == addCarInfoModel.EuroStandard)
                        .Id;
                carToAdd.EuroStandardId = euroStandardId;
            }

            int doorsId = context.DoorCounts
                    .FirstOrDefault(m => m.DoorsConfiguration == addCarInfoModel.Doors)
                    .Id;
            carToAdd.DoorsId = doorsId;

            if (!String.IsNullOrEmpty(addCarInfoModel.EuroStandard))
            {
                int paintsId = context.Paints
                    .FirstOrDefault(m => m.Color == addCarInfoModel.Paint)
                    .Id;
                carToAdd.PaintId = doorsId;
            }


            carToAdd.Modification = addCarInfoModel.Modification;
            carToAdd.EngineCapacity = addCarInfoModel.EngineCapacity;
            carToAdd.EnginePower = addCarInfoModel.EnginePower;
            carToAdd.Kilometers = addCarInfoModel.Kilometers;
            carToAdd.Price = addCarInfoModel.Price;
            carToAdd.Information = addCarInfoModel.Information;

            context.Add(carToAdd);
            context.SaveChanges();

            int addedCarId = context.Cars.OrderByDescending(c => c.Id).FirstOrDefault().Id;

            List<CarExtra> carExtrasToAdd = new List<CarExtra>();

            foreach (var item in addCarInfoModel.CarExtras)
            {
                CarExtra currentCarExtra = new CarExtra();
                currentCarExtra.CarId = addedCarId;
                int currentExtraId = context.Extras
                    .FirstOrDefault(e => e.ExtraType == item)
                    .Id;
                currentCarExtra.ExtraId = currentExtraId;

                context.CarsExtras.Add(currentCarExtra);
            }

            context.SaveChanges();

            int newCarsCount = context.Cars.Count();

            if (carsCount < newCarsCount)
            {
                string carName = context.Cars.OrderByDescending(c => c.Id).FirstOrDefault().Make.MakeName;
                string carModel = context.Cars.OrderByDescending(c => c.Id).FirstOrDefault().CarModel.ModelName;
                message = $"Successfully added new car: {carName} {carModel}";
            }
            return message;
        }

        /// <summary>
        /// This method adds a new make to the database
        /// </summary>
        /// <param name="context"></param>
        /// <param name="makeName"></param>
        /// <returns>message from type string that shows whether
        /// the new make is succesfully added or no</returns>
        public string AddNewMakeToDB(Car1DealerContext context, string makeName)
        {

            string message = "New make failed to add.";

            int existingMakeCount = context.Makes.Where(m => m.MakeName == makeName).Count();

            if (existingMakeCount > 0)
            {

                message = "The make allready exists";
            }
            else if (String.IsNullOrEmpty(makeName))
            {
                message = "The make name can not be empty";
            }
            else
            {
                Make makeToAdd = new Make();
                makeToAdd.MakeName = makeName;

                context.Makes.Add(makeToAdd);
                context.SaveChanges();

                int existingNewMakeCount = context.Makes.Where(m => m.MakeName == makeName).Count();

                if (existingNewMakeCount > 0)
                {                    
                    message = $"Succsessfully added new make: {makeName}";
                }
            }

            return message;
        }


        /// <summary>
        /// This method adds a new model to the database
        /// </summary>
        /// <param name="context"></param>
        /// <param name="makeName"></param>
        /// <param name="modelName"></param>
        /// <returns>message from type string that shows whether
        /// the new model is succesfully added or no</returns>
        public string AddNewModelToDB(Car1DealerContext context, string makeName, string modelName)
        {
            string message = "New model failed to add.";

            Make currentMake = context.Makes.FirstOrDefault(m => m.MakeName == makeName);

            if (currentMake == null)
            {
                message = "The make of the model does not exist.";
            }

            else
            {
                int existingModelCount = context.CarModels
                    .Where(m => m.MakeId == currentMake.Id && m.ModelName == modelName).Count();

                if (existingModelCount > 0)
                {

                    message = "The model allready exists";
                }
                else if (String.IsNullOrEmpty(modelName))
                {
                    message = "The model name can not be empty";
                }

                else
                {
                    CarModel modelToAdd = new CarModel();
                    modelToAdd.ModelName = modelName;
                    modelToAdd.MakeId = currentMake.Id;

                    context.CarModels.Add(modelToAdd);
                    context.SaveChanges();

                    CarModel newModel = context.CarModels.Where(m => m.ModelName == modelName).FirstOrDefault(m => m.MakeId == currentMake.Id);

                    if (newModel != null)
                    {                        
                        message = $"Succsessfully added new model {modelName} to make: {makeName}";
                    }
                }
            }

            return message;
        }


        /// <summary>
        /// This method adds a new paint to the database
        /// </summary>
        /// <param name="context"></param>
        /// <param name="colorName"></param>
        /// <returns>message from type string that shows whether
        /// the new paint is succesfully added or no</returns>
        public string AddNewPaintToDB(Car1DealerContext context, string colorName)
        {

            string message = "New color failed to add.";

            int existingColorCount = context.Paints.Where(p => p.Color == colorName).Count();

            if (existingColorCount > 0)
            {

                message = "The color allready exists";
            }
            else if (String.IsNullOrEmpty(colorName))
            {
                message = "The color name can not be empty";
            }

            else
            {
                Paint colorToAdd = new Paint();
                colorToAdd.Color = colorName;

                context.Paints.Add(colorToAdd);
                context.SaveChanges();

                int existingNewColorCount = context.Paints.Where(p => p.Color == colorName).Count();

                if (existingNewColorCount > 0)
                {
                    message = $"Succsessfully added new color: {colorName}";
                }
            }

            return message;
        }


        /// <summary>
        /// This method adds a new extra to the database
        /// </summary>
        /// <param name="context"></param>
        /// <param name="extraName"></param>
        /// <returns>message from type string that shows whether
        /// the new extra is succesfully added or no</returns>
        public string AddNewExtraToDB(Car1DealerContext context, string extraName)
        {

            string message = "New extra failed to add.";

            int existingExtraCount = context.Extras.Where(e => e.ExtraType == extraName).Count();

            if (existingExtraCount > 0)
            {

                message = "The extra allready exists";
            }
            else if (String.IsNullOrEmpty(extraName))
            {
                message = "The extra name can not be empty";
            }

            else
            {
                Extra extraToAdd = new Extra();
                extraToAdd.ExtraType = extraName;

                context.Extras.Add(extraToAdd);
                context.SaveChanges();

                int existingNewExtraCount = context.Extras.Where(e => e.ExtraType == extraName).Count();

                if (existingNewExtraCount > 0)
                {
                    message = $"Succsessfully added new extra: {extraName}";
                }
            }

            return message;
        }


        /// <summary>
        /// This method adds a new type to the database
        /// </summary>
        /// <param name="context"></param>
        /// <param name="typeName"></param>
        /// <returns>message from type string that shows whether
        /// the new type is succesfully added or no</returns>
        public string AddNewTypeToDB(Car1DealerContext context, string typeName)
        {

            string message = "New type failed to add.";

            int existingTypeCount = context.VehicleTypes.Where(t => t.TypeName == typeName).Count();

            if (existingTypeCount > 0)
            {

                message = "The type allready exists";
            }
            else if (String.IsNullOrEmpty(typeName))
            {
                message = "The type name can not be empty";
            }

            else
            {
                VehicleType typeToAdd = new VehicleType();
                typeToAdd.TypeName = typeName;

                context.VehicleTypes.Add(typeToAdd);
                context.SaveChanges();

                int existingNewTypeCount = context.VehicleTypes.Where(t => t.TypeName == typeName).Count();

                if (existingNewTypeCount > 0)
                {
                    message = $"Succsessfully added new type: {typeName}";
                }
            }

            return message;
        }

    }
}
