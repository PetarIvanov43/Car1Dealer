﻿using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.DataOperations
{
    /*
     * This class deletes data from the database using a method
     */
    public class DeleteDataOperations
    {
        /// <summary>
        /// This method deletes a car from the database using the parameter id to find which object car
        /// has to be deleted
        /// </summary>
        /// <param name="context"></param>
        /// <param name="id"></param>
        /// <returns>message from type string that shows whether
        /// the car is succesfully removed or no</returns>
        public string DeleteCarFromDB(Car1DealerContext context, int id)
        {
            int carsCount = context.Cars.Count();
            string message = "The car failed to remove";

            Car deletedCar = context.Cars.FirstOrDefault(c => c.Id == id);
            context.Cars.Remove(deletedCar);

            context.SaveChanges();

            int newCarsCount = context.Cars.Count();

            if (carsCount > newCarsCount)
            {
                message = $"The car is successfully removed!";
            }

            return message;

        }
    }
}
