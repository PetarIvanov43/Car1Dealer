﻿using Business.ViewModels;
using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.DataOperations
{
    /*
     * Gets data from the database 
    */
    public class GetDataOperations
    {

        //public bool CheckCarAvailabilityById(Car1DealerContext context, int id)
        //{
        //    int count = context.Cars.Where(c => c.Id == id).Count();
        //    if (count == 0)
        //    {
        //        return false;
        //    }
        //    else
        //    {
        //        return true;
        //    }
        //}

        /// <summary>
        /// Checks the availability of car in the database finding the car using the parameter id
        /// </summary>
        /// <param name="context"></param>
        /// <param name="id"></param>
        /// <returns>true or false</returns>
        public bool CheckCarAvailabilityById(Car1DealerContext context, int id)
        {
            Car car = context.Cars.FirstOrDefault(c => c.Id == id);

            if (car != null)
            {
                return car.AdAvailable;
            }

            else
            {
                return false;
            }
        }

        /// <summary>
        /// Gets all the makes from the database
        /// </summary>
        /// <param name="context"></param>
        /// <returns>list from all the makes which are type string</returns>
        public List<string> GetAllMakes(Car1DealerContext context)
        {
            List<string> makesStr = context.Makes.Select(m => m.MakeName).ToList();
            makesStr.Sort();
            return makesStr;
        }

        /// <summary>
        /// Gets all the models from the database
        /// </summary>
        /// <param name="context"></param>
        /// <param name="make"></param>
        /// <returns>list from all the models which are type string</returns>
        public static List<string> GetAllModelsForMake(Car1DealerContext context, string make)
        {
            List<string> makesStr = context.CarModels
                .Where(m => m.Make.MakeName == make)
                .Select(m => m.ModelName)
                .ToList();

            makesStr.Sort();
            return makesStr;
        }

        /// <summary>
        /// Gets all the types of fuel from the database
        /// </summary>
        /// <param name="context"></param>
        /// <returns>list from all the types of fuel which are type string</returns>
        public List<string> GetAllFuels(Car1DealerContext context)
        {
            return context.FuelTypes.Select(f => f.FuelType).ToList();
        }

        /// <summary>
        /// Gets all the vehicle types from the database
        /// </summary>
        /// <param name="context"></param>
        /// <returns>list from all the vehicle types which are type string</returns>
        public List<string> GetAllTypes(Car1DealerContext context)
        {
            List<string> typesStr = context.VehicleTypes.Select(t => t.TypeName).ToList();
            typesStr.Sort();
            return typesStr;
        }

        /// <summary>
        /// Gets all the types of gearbox from the database
        /// </summary>
        /// <param name="context"></param>
        /// <returns>list from all the types of gearbox which are type string</returns>
        public List<string> GetAllGearboxs(Car1DealerContext context)
        {
            List<string> gearboxesStr = context.Gearboxes.Select(g => g.GearboxType).ToList();
            gearboxesStr.Sort();
            return gearboxesStr;
        }

        /// <summary>
        /// Gets all door counts from the database
        /// </summary>
        /// <param name="context"></param>
        /// <returns>list from all door counts which are type string</returns>
        public List<string> GetAllDoors(Car1DealerContext context)
        {
            List<string> doorsStr = context.DoorCounts.Select(d => d.DoorsConfiguration).ToList();
            doorsStr.Sort();
            return doorsStr;
        }

        /// <summary>
        /// Gets all the extras from the database
        /// </summary>
        /// <param name="context"></param>
        /// <returns>list from all the extras which are type string</returns>
        public List<string> GetAllExtras(Car1DealerContext context)
        {
            List<string> extrasStr = context.Extras.Select(e => e.ExtraType).ToList();
            extrasStr.Sort();
            return extrasStr;
        }

        /// <summary>
        /// Gets every eurostandard type from the database
        /// </summary>
        /// <param name="context"></param>
        /// <returns>list from every eurostandard type which are type string</returns>
        public List<string> GetAllEuroStandards(Car1DealerContext context)
        {
            List<string> euroStandardsStr = context.EuroStandards.Select(e => e.EuroStandardType).ToList();
            euroStandardsStr.Sort();
            return euroStandardsStr;
        }

        /// <summary>
        /// Gets all the paints from the database
        /// </summary>
        /// <param name="context"></param>
        /// <returns>list from all the paints which are type string</returns>
        public List<string> GetAllPaints(Car1DealerContext context)
        {
            List<string> paintsStr = context.Paints.Select(e => e.Color).ToList();
            paintsStr.Sort();
            return paintsStr;
        }

        /// <summary>
        /// Gets the preview info about model from the database
        /// </summary>
        /// <param name="context"></param>
        /// <param name="searchCriteria"></param>
        /// <returns>list from all the preview info about model which are type string</returns>
        public List<CarPreviewModel> GetPreviewInfo(Car1DealerContext context, CarSearchDataModel searchCriteria)
        {
            string[] checkExtrasArray = new string[20]; // Allows to check for maximum 20 possible extras.

            int extrasCounter = 0;

            foreach (var extra in searchCriteria.SlectadExtras)
            {
                checkExtrasArray[extrasCounter] = extra;
                extrasCounter += 1;
                if (extrasCounter > 19) // Allows to check for maximum 20 possible extras.
                {
                    break;
                }
            }

            var models = context.Cars
                .Where(c => c.AdAvailable)
                .Where(m => string.IsNullOrEmpty(searchCriteria.SelectedMake) || searchCriteria.SelectedMake == "(no)" || m.Make.MakeName == searchCriteria.SelectedMake)
                .Where(m => string.IsNullOrEmpty(searchCriteria.SelectedModel) || searchCriteria.SelectedModel == "(no)" || m.CarModel.ModelName == searchCriteria.SelectedModel)
                .Where(f => string.IsNullOrEmpty(searchCriteria.SelectedFuel) || searchCriteria.SelectedFuel == "(no)" || f.Fuel.FuelType == searchCriteria.SelectedFuel)
                .Where(d => string.IsNullOrEmpty(searchCriteria.SelectedDoors) || searchCriteria.SelectedDoors == "(no)" || d.Doors.DoorsConfiguration == searchCriteria.SelectedDoors)
                .Where(t => string.IsNullOrEmpty(searchCriteria.SelectedType) || searchCriteria.SelectedType == "(no)" || t.Type.TypeName == searchCriteria.SelectedType)
                .Where(g => string.IsNullOrEmpty(searchCriteria.SelectedGearbox) || searchCriteria.SelectedGearbox == "(no)" || g.Gearbox.GearboxType == searchCriteria.SelectedGearbox)
                .Where(hp => searchCriteria.MinEnginePower == 0 || hp.EnginePower >= searchCriteria.MinEnginePower)
                .Where(hp => searchCriteria.MaxEnginePower == 0 || hp.EnginePower <= searchCriteria.MaxEnginePower)
                .Where(p => searchCriteria.MinPrice == 0 || p.Price >= searchCriteria.MinPrice)
                .Where(p => searchCriteria.MaxPrice == 0 || p.Price <= searchCriteria.MaxPrice)

                //The next 20 where clauses check for maximum 20 posible extras. Those are loaded in checkExtrasArray[].

                .Where(c => string.IsNullOrEmpty(checkExtrasArray[0]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[0]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[1]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[1]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[2]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[2]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[3]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[3]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[4]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[4]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[5]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[5]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[6]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[6]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[7]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[7]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[8]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[8]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[9]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[9]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[10]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[10]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[11]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[11]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[12]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[12]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[13]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[13]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[14]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[14]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[15]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[15]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[16]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[16]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[17]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[17]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[18]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[18]))
                .Where(c => string.IsNullOrEmpty(checkExtrasArray[19]) || c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == checkExtrasArray[19]))
                .OrderBy(c => c.Price)
                .Select(c => new CarPreviewModel(
                    c.Id,
                    c.Make.MakeName,
                    c.CarModel.ModelName,
                    c.Modification,
                    c.Kilometers,
                    c.Fuel.FuelType,
                    c.Price
                ))
                .ToList();

            return models;
        }


        /// <summary>
        /// Gets the full info about car from the database
        /// </summary>
        /// <param name="context"></param>
        /// <param name="id"></param>
        /// <returns>list from all the full info about model which are type string</returns>
        public CarFullInfoModel GetFullInfo(Car1DealerContext context, int id)
        {
            var resultCarInfo = context.Cars
                .Where(c => c.Id == id)
                .Select(c => new CarFullInfoModel(
                    c.Id,
                    c.Make.MakeName,
                    c.CarModel.ModelName,
                    c.Modification,
                    c.Fuel.FuelType,
                    c.Type.TypeName,
                    c.EngineCapacity,
                    c.EnginePower,
                    c.Gearbox.GearboxType,
                    c.EuroStandard.EuroStandardType,
                    c.Doors.DoorsConfiguration,
                    c.Kilometers,
                    c.Paint.Color,
                    c.Information,
                    c.Price
                ))
                .FirstOrDefault();
            if (resultCarInfo != null)
            {
                List<string> extras = context.CarsExtras
                .Where(c => c.CarId == id)
                .Select(e => e.Extra.ExtraType)
                .ToList();

                extras.Sort();

                resultCarInfo.CarExtras = extras;
            }

            return resultCarInfo;
        }
    }
}
